/*
	Project 1
	Problem misionaris dan kanibal
	Kecerdasan Buatan B
	Dosen : Isye Arieshanti
	Nama : Fendy
	NRP : 5113100017
	Metode search : DFS
*/

#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
using namespace std;

#define INF 10000000

typedef struct{
	int kanibal;
	int misionaris;
	int perahu;
}state;//struct untuk menyatakan kondisi sekarang

int langkah[4][4][3];//untuk menyimpan jarak terpendek
state trace[4][4][3];//menyimpan step-step untuk menampilkan solusi

void DFS(int kanibalkiri, int misionariskiri, int perahu, int step){
	if(kanibalkiri==0 && misionariskiri==0)return;//goal
	
	int kanibalkanan=3-kanibalkiri; int misionariskanan=3-misionariskiri;//untuk mendaptkan banyak kanibal dan misionaris di ruas kanan
	//kondisi game kalah
	if(misionariskiri < kanibalkiri && misionariskiri!=0)return;
	if(misionariskanan < kanibalkanan && misionariskanan!=0)return;
	
	//disimpan kondisi sekarang untuk proses menampilkan solusi
	state temp;
	temp.kanibal=kanibalkiri;
	temp.misionaris=misionariskiri;
	temp.perahu=perahu;
	
	if(perahu==0){//kalau perahu di sebelah kiri
		if(kanibalkiri>=2){//pindahkan 2 kanibal
			if(langkah[kanibalkiri-2][misionariskiri][1]>step+1){//untuk memastikan bahwa step yang akan dicoba lebih menguntungkan
				langkah[kanibalkiri-2][misionariskiri][1]=step+1;
				trace[kanibalkiri-2][misionariskiri][1]=temp;
				DFS(kanibalkiri-2,misionariskiri,1,step+1);
			}
		}
		if(misionariskiri>=2){//pindahkan 2 misionaris
			if(langkah[kanibalkiri][misionariskiri-2][1]>step+1){
				langkah[kanibalkiri][misionariskiri-2][1]=step+1;
				trace[kanibalkiri][misionariskiri-2][1]=temp;
				DFS(kanibalkiri,misionariskiri-2,1,step+1);
			}
		}
		if(misionariskiri>=1 && kanibalkiri>=1){//pindahkan 1 misionaris dan 1 kanibal;
			if(langkah[kanibalkiri-1][misionariskiri-1][1]>step+1){
				langkah[kanibalkiri-1][misionariskiri-1][1]=step+1;
				trace[kanibalkiri-1][misionariskiri-1][1]=temp;
				DFS(kanibalkiri-1,misionariskiri-1,1,step+1);
			}
		}
	}else{//kalau perahu di sebelah kanan
		if(kanibalkanan>=2){//pindahkan 2 kanibal ke kiri
			if(langkah[kanibalkiri+2][misionariskiri][0]>step+1){//untuk memastikan bahwa step ini lebih menguntungkan
				langkah[kanibalkiri+2][misionariskiri][0]=step+1;
				trace[kanibalkiri+2][misionariskiri][0]=temp;
				DFS(kanibalkiri+2,misionariskiri,0,step+1);
			}
		}
		if(misionariskanan>=2){//pindahkan 2 misionaris ke kiri
			if(langkah[kanibalkiri][misionariskiri+2][0]>step+1){
				langkah[kanibalkiri][misionariskiri+2][0]=step+1;
				trace[kanibalkiri][misionariskiri+2][0]=temp;
				DFS(kanibalkiri,misionariskiri+2,0,step+1);
			}
		}
		if(misionariskanan>=1 && kanibalkanan>=1){//pindahkan 1 misionaris dan 1 kanibal ke kiri
			if(langkah[kanibalkiri+1][misionariskiri+1][0]>step+1){
				langkah[kanibalkiri+1][misionariskiri+1][0]=step+1;
				trace[kanibalkiri+1][misionariskiri+1][0]=temp;
				DFS(kanibalkiri+1,misionariskiri+1,0,step+1);
			}
		}
		if(kanibalkanan>=1){//pindahkan 1 kanibal saja ke kiri
			if(langkah[kanibalkiri+1][misionariskiri][0]>step+1){
				langkah[kanibalkiri+1][misionariskiri][0]=step+1;
				trace[kanibalkiri+1][misionariskiri][0]=temp;
				DFS(kanibalkiri+1,misionariskiri,0,step+1);
			}
		}
		if(misionariskanan>=1){//pindahkan 1 misionaris saja ke kiri
			if(langkah[kanibalkiri][misionariskiri+1][0]>step+1){
				langkah[kanibalkiri][misionariskiri+1][0]=step+1;
				trace[kanibalkiri][misionariskiri+1][0]=temp;
				DFS(kanibalkiri,misionariskiri+1,0,step+1);
			}
		}
	}
}

int main(){
	//set langkah ke semua state jadi tak terhingga
	//berfungsi sebagai flag juga
	for(int x=0;x<=3;x++){
		for(int y=0;y<=3;y++){
			for(int z=0;z<=1;z++){
				langkah[x][y][z]=INF;
			}
		}
	}
	
	DFS(3,3,0,0);//mulai traverse
	state answer[20];//menyimpan urutan solusi
	state tmp;
	int n=0;//panjang solusi
	tmp.kanibal=0; tmp.misionaris=0; tmp.perahu=1;
	
	//backtrack solusi dari goal
	answer[n++]=tmp;
	while(tmp.kanibal!=3 || tmp.misionaris!=3 || tmp.perahu!=0){//sampai belum kembali ke start
		tmp=trace[tmp.kanibal][tmp.misionaris][tmp.perahu];//mundur ke state sebelumnya
		answer[n++]=tmp;
	}
	
	printf("Simulasi game misionaris dan kanibal\n");
	printf("Ketentuan: di suatu sisi baik kiri atau kanan jumlah kanibal tidak boleh melebihi jumlah misionaris\n");
	printf("Terdapat 3 kanibal dan 3 misionaris di sisi kiri sungai\n");
	printf("Perahu harus terisi orang agar dapat bergerak dari satu sisi sungai ke sisi lainnya\n\n");
	
	printf("Solusi\n");
	for(int x=n-1;x>=0;x--){
		printf("Posisi Sekarang: ");
		printf("%dK-%dM ",answer[x].kanibal,answer[x].misionaris);
		if(!answer[x].perahu)printf("P");
		printf("----------");
		if(answer[x].perahu)printf("P");
		printf(" %dK-%dM\n",3-answer[x].kanibal,3-answer[x].misionaris);
		if(x){
			printf("Pindahkan: %d kanibal %d misionaris ",abs(answer[x-1].kanibal-answer[x].kanibal),abs(answer[x].misionaris-answer[x-1].misionaris));
			if(!answer[x].perahu)printf("ke kanan\n");
			else printf("ke kiri\n");	
		}
		//printf("%d %d %d\n",answer[x].kanibal,answer[x].misionaris,answer[x].perahu);
	}
	printf("Solved\n");
	return 0;
}
